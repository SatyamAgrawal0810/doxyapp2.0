import 'package:flutter/material.dart';

class HealthScreen extends StatefulWidget {
  const HealthScreen({Key? key}) : super(key: key);

  @override
  State<HealthScreen> createState() => _HealthScreenState();
}

class _HealthScreenState extends State<HealthScreen> {
  double _waterIntake = 1.5;
  double _sleepHours = 6.5;
  int _steps = 6500;
  int _heartRate = 80;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('Health Tracker'),
        backgroundColor: const Color(0xFF1A1A1A),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            const Text(
              "Today's Health Summary",
              style: TextStyle(
                color: Colors.white,
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),

            // Heart Rate
            _HealthCard(
              title: "Heart Rate",
              value: "$_heartRate bpm",
              icon: Icons.favorite_border,
              color: Colors.redAccent,
              onTap: () {
                setState(() {
                  _heartRate = 78 + (5 - (_heartRate % 10));
                });
              },
            ),

            // Steps
            _HealthCard(
              title: "Steps",
              value: "$_steps",
              icon: Icons.directions_walk,
              color: Colors.orangeAccent,
              onTap: () {
                setState(() => _steps += 500);
              },
            ),

            // Water Intake
            _HealthCard(
              title: "Water Intake",
              value: "${_waterIntake.toStringAsFixed(1)} L",
              icon: Icons.water_drop_outlined,
              color: Colors.lightBlueAccent,
              onTap: () {
                setState(() {
                  _waterIntake += 0.2;
                  if (_waterIntake > 3.0) _waterIntake = 1.2;
                });
              },
            ),

            // Sleep Hours
            _HealthCard(
              title: "Sleep",
              value: "${_sleepHours.toStringAsFixed(1)} hrs",
              icon: Icons.nightlight_round,
              color: Colors.purpleAccent,
              onTap: () {
                setState(() {
                  _sleepHours = 6 + (1.5 - (_sleepHours % 2));
                });
              },
            ),

            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Health data synced successfully ✅'),
                  ),
                );
              },
              icon: const Icon(Icons.sync),
              label: const Text('Sync Data'),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFF6A00),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HealthCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const _HealthCard({
    required this.title,
    required this.value,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 16),
        decoration: BoxDecoration(
          color: const Color(0xFF1A1A1A),
          borderRadius: BorderRadius.circular(14),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: color.withOpacity(0.15),
              child: Icon(icon, color: color),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Text(
                title,
                style: const TextStyle(color: Colors.white, fontSize: 18),
              ),
            ),
            Text(
              value,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            )
          ],
        ),
      ),
    );
  }
}
