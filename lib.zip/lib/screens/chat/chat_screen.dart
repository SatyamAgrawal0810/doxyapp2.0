// lib/screens/chat_screen.dart - FIXED VERSION

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../services/chat_service.dart';
import '../../services/auth_service.dart';
import 'controllers/chat_controller.dart';
import 'widgets/chat_bubble.dart';
import 'widgets/typing_indicator.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({Key? key}) : super(key: key);

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen>
    with AutomaticKeepAliveClientMixin {
  ChatController? _controller;
  final TextEditingController _msgCtl = TextEditingController();
  final ScrollController _scroll = ScrollController();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  bool _isSending = false;
  bool _isInitialized = false;
  bool _isDisposed = false;

  // Keep state alive when switching tabs
  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted && !_isDisposed) {
        _initializeChat();
      }
    });
  }

  void _initializeChat() async {
    if (_isInitialized || _isDisposed) return;

    try {
      final auth = Provider.of<AuthService>(context, listen: false);
      final service = ChatService(
        baseUrl: 'https://doxy-bh96.onrender.com/api/chat',
        auth: auth,
      );

      _controller = ChatController(service);
      _controller!.addListener(_onControllerChanged);

      setState(() {
        _isInitialized = true;
      });

      // Load initial data
      await _loadInitial();
    } catch (e) {
      print('❌ Chat initialization error: $e');
      if (mounted && !_isDisposed) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to initialize chat: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _loadInitial() async {
    if (_controller == null || _isDisposed) return;

    try {
      await _controller!.loadSessions();

      if (!mounted || _isDisposed) return;

      // Auto-create first chat if none exist
      if (_controller!.sessions.isEmpty) {
        await _createNewChat();
      } else {
        // Open the most recent session
        final sessions = _controller!.sessions;
        if (sessions.isNotEmpty) {
          final last = sessions.last;
          final id = last['_id'] ?? last['id'];
          if (id != null) {
            await _controller!.openSession(id);
          }
        }
      }
    } catch (e) {
      print('❌ Load initial error: $e');
    }
  }

  @override
  void dispose() {
    _isDisposed = true;
    _controller?.removeListener(_onControllerChanged);
    _controller?.dispose();
    _msgCtl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _onControllerChanged() {
    if (_isDisposed || !mounted) return;

    // Auto-scroll to bottom when new messages arrive
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_isDisposed && mounted && _scroll.hasClients) {
        try {
          _scroll.animateTo(
            _scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeOut,
          );
        } catch (e) {
          print('Scroll error: $e');
        }
      }
    });

    if (mounted && !_isDisposed) {
      setState(() {});
    }
  }

  Future<void> _createNewChat() async {
    if (_controller == null || _isDisposed) return;

    try {
      await _controller!.createSession();

      if (!mounted || _isDisposed) return;

      if (_controller!.sessions.isNotEmpty) {
        final last = _controller!.sessions.last;
        final id = last['_id'] ?? last['id'];
        if (id != null) {
          await _controller!.openSession(id);
        }
      }
    } catch (e) {
      print('❌ Create chat error: $e');
      if (mounted && !_isDisposed) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to create chat: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _selectSession(String id) async {
    if (_controller == null || _isDisposed) return;

    try {
      await _controller!.openSession(id);
      if (Navigator.canPop(context) && mounted) {
        Navigator.pop(context); // Close drawer on mobile
      }
    } catch (e) {
      print('❌ Select session error: $e');
    }
  }

  Future<void> _deleteSession(String id) async {
    if (_controller == null || _isDisposed || !mounted) return;

    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: const Text('Delete Chat', style: TextStyle(color: Colors.white)),
        content: const Text(
          'Are you sure you want to delete this chat?',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirm != true || _isDisposed || !mounted) return;

    try {
      await _controller!.deleteSession(id);

      if (_isDisposed || !mounted) return;

      // Create new chat if all deleted
      if (_controller!.sessions.isEmpty) {
        await _createNewChat();
      } else {
        // Open last available session
        final sessions = _controller!.sessions;
        if (sessions.isNotEmpty) {
          final last = sessions.last;
          final lastId = last['_id'] ?? last['id'];
          if (lastId != null) {
            await _controller!.openSession(lastId);
          }
        }
      }
    } catch (e) {
      print('❌ Delete session error: $e');
    }
  }

  Future<void> _sendMessage() async {
    if (_controller == null || _isDisposed || !mounted) return;

    final text = _msgCtl.text.trim();
    if (text.isEmpty || _controller!.openedSession == null) return;

    if (!mounted || _isDisposed) return;

    setState(() => _isSending = true);

    try {
      await _controller!.sendMessage(text);
      _msgCtl.clear();
    } catch (e) {
      print('❌ Send message error: $e');
      if (mounted && !_isDisposed) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to send message: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted && !_isDisposed) {
        setState(() => _isSending = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context); // Required for AutomaticKeepAliveClientMixin

    if (!_isInitialized || _controller == null) {
      return Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: const [
              CircularProgressIndicator(color: Color(0xFFFF6A00)),
              SizedBox(height: 16),
              Text(
                'Initializing chat...',
                style: TextStyle(color: Colors.grey),
              ),
            ],
          ),
        ),
      );
    }

    final width = MediaQuery.of(context).size.width;
    final isMobile = width < 800;

    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: Colors.black,
      appBar: isMobile
          ? AppBar(
              backgroundColor: const Color(0xFF1A1A1A),
              title: const Text('AI Chat'),
              centerTitle: true,
              leading: IconButton(
                icon: const Icon(Icons.menu),
                onPressed: () => _scaffoldKey.currentState?.openDrawer(),
              ),
              actions: [
                IconButton(
                  icon: const Icon(Icons.add),
                  onPressed: _createNewChat,
                ),
              ],
            )
          : null,
      drawer: isMobile ? _buildDrawer() : null,
      body: SafeArea(
        child: Row(
          children: [
            if (!isMobile) _buildSidebar(360),
            Expanded(child: _buildChatArea()),
          ],
        ),
      ),
    );
  }

  // 📱 SIDEBAR (Desktop)
  Widget _buildSidebar(double width) {
    return Container(
      width: width,
      decoration: const BoxDecoration(
        color: Color(0xFF1A1A1A),
        border: Border(
          right: BorderSide(color: Color(0xFF333333), width: 1),
        ),
      ),
      child: Column(
        children: [
          _buildSidebarHeader(),
          _buildSessionsList(),
        ],
      ),
    );
  }

  // 📱 DRAWER (Mobile)
  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: const Color(0xFF1A1A1A),
      child: Column(
        children: [
          _buildSidebarHeader(),
          _buildSessionsList(),
        ],
      ),
    );
  }

  // 🎯 SIDEBAR HEADER
  Widget _buildSidebarHeader() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFFFF8A00), Color(0xFFFF6A00)],
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              const Icon(Icons.chat_bubble, color: Colors.white, size: 24),
              const SizedBox(width: 12),
              const Expanded(
                child: Text(
                  'Chat History',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.add, color: Colors.white),
                onPressed: _createNewChat,
                tooltip: 'New Chat',
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: const [
                Icon(Icons.search, color: Colors.white70, size: 18),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Search chats...',
                    style: TextStyle(color: Colors.white70, fontSize: 14),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // 📋 SESSIONS LIST
  Widget _buildSessionsList() {
    if (_controller == null) {
      return const Expanded(
        child: Center(
          child: CircularProgressIndicator(color: Color(0xFFFF6A00)),
        ),
      );
    }

    if (_controller!.loadingSessions) {
      return const Expanded(
        child: Center(
          child: CircularProgressIndicator(color: Color(0xFFFF6A00)),
        ),
      );
    }

    if (_controller!.sessions.isEmpty) {
      return Expanded(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.chat_bubble_outline,
                  size: 64, color: Colors.grey[700]),
              const SizedBox(height: 16),
              Text(
                'No conversations yet',
                style: TextStyle(color: Colors.grey[600], fontSize: 16),
              ),
              const SizedBox(height: 8),
              ElevatedButton.icon(
                onPressed: _createNewChat,
                icon: const Icon(Icons.add),
                label: const Text('Start New Chat'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFFF6A00),
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Expanded(
      child: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: _controller!.sessions.length,
        itemBuilder: (context, i) {
          final session = _controller!.sessions[i];
          final id = session['_id'] ?? session['id'];
          final title = session['title'] ?? 'New Chat';
          final lastMsg = session['lastMessage'] ?? '';
          final msgCount = session['messageCount'] ?? 0;
          final isActive = _controller!.openedSession == id;

          return Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: () => _selectSession(id),
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: isActive
                        ? const Color(0xFF2A2A2A)
                        : const Color(0xFF1E1E1E),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: isActive
                          ? const Color(0xFFFF6A00)
                          : Colors.transparent,
                      width: 2,
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: const Color(0xFFFF6A00).withOpacity(0.2),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(
                          Icons.chat_bubble_outline,
                          color: Color(0xFFFF6A00),
                          size: 20,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              title,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                                fontWeight: isActive
                                    ? FontWeight.bold
                                    : FontWeight.normal,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            if (lastMsg.isNotEmpty) ...[
                              const SizedBox(height: 4),
                              Text(
                                lastMsg,
                                style: TextStyle(
                                  color: Colors.grey[500],
                                  fontSize: 12,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                            const SizedBox(height: 4),
                            Text(
                              '$msgCount messages',
                              style: TextStyle(
                                color: Colors.grey[600],
                                fontSize: 11,
                              ),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        icon:
                            const Icon(Icons.delete_outline, color: Colors.red),
                        iconSize: 20,
                        onPressed: () => _deleteSession(id),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  // 💬 CHAT AREA
  Widget _buildChatArea() {
    if (_controller == null) {
      return const Center(
        child: CircularProgressIndicator(color: Color(0xFFFF6A00)),
      );
    }

    final sid = _controller!.openedSession;

    if (sid == null) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(color: Color(0xFFFF6A00)),
            SizedBox(height: 16),
            Text(
              'Loading chat...',
              style: TextStyle(color: Colors.grey),
            ),
          ],
        ),
      );
    }

    final messages = _controller!.getCurrentMessages();

    return Column(
      children: [
        // Chat Header
        if (MediaQuery.of(context).size.width >= 800)
          Container(
            padding: const EdgeInsets.all(16),
            decoration: const BoxDecoration(
              color: Color(0xFF1A1A1A),
              border: Border(
                bottom: BorderSide(color: Color(0xFF333333)),
              ),
            ),
            child: Row(
              children: [
                const Icon(Icons.smart_toy, color: Color(0xFFFF6A00)),
                const SizedBox(width: 12),
                const Expanded(
                  child: Text(
                    'AI Assistant',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.delete_outline, color: Colors.red),
                  onPressed: () => _controller!.clearSession(sid),
                  tooltip: 'Clear chat',
                ),
              ],
            ),
          ),

        // Messages
        Expanded(
          child: messages.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.chat_bubble_outline,
                          size: 64, color: Colors.grey[700]),
                      const SizedBox(height: 16),
                      Text(
                        'Start a conversation',
                        style: TextStyle(
                          color: Colors.grey[600],
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Ask me anything!',
                        style: TextStyle(
                          color: Colors.grey[700],
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  controller: _scroll,
                  padding: const EdgeInsets.all(16),
                  itemCount: messages.length + (_controller!.typing ? 1 : 0),
                  itemBuilder: (context, idx) {
                    if (idx == messages.length && _controller!.typing) {
                      return const TypingIndicator();
                    }
                    return ChatBubble(message: messages[idx]);
                  },
                ),
        ),

        // Input Area
        Container(
          padding: const EdgeInsets.all(12),
          decoration: const BoxDecoration(
            color: Color(0xFF1A1A1A),
            border: Border(
              top: BorderSide(color: Color(0xFF333333)),
            ),
          ),
          child: SafeArea(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Expanded(
                  child: Container(
                    constraints: const BoxConstraints(maxHeight: 150),
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    decoration: BoxDecoration(
                      color: const Color(0xFF2A2A2A),
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: TextField(
                      controller: _msgCtl,
                      style: const TextStyle(color: Colors.white),
                      maxLines: null,
                      textInputAction: TextInputAction.newline,
                      decoration: const InputDecoration(
                        hintText: 'Type a message...',
                        hintStyle: TextStyle(color: Colors.grey),
                        border: InputBorder.none,
                      ),
                      onSubmitted: (_) => _sendMessage(),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFF8A00), Color(0xFFFF6A00)],
                    ),
                    borderRadius: BorderRadius.circular(24),
                  ),
                  child: IconButton(
                    icon: _isSending
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2,
                            ),
                          )
                        : const Icon(Icons.send, color: Colors.white),
                    onPressed: _isSending ? null : _sendMessage,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
