import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../screens/calendar_screen.dart';
import 'chat/chat_screen.dart';
import '../screens/home_dashboard.dart';
import '../screens/health_screen.dart';
import '../services/auth_service.dart';
import 'login_page.dart';

class MainWrapper extends StatefulWidget {
  const MainWrapper({Key? key}) : super(key: key);

  @override
  State<MainWrapper> createState() => _MainWrapperState();
}

class _MainWrapperState extends State<MainWrapper> {
  int _idx = 0;

  final _pages = const [
    HomeDashboard(),
    EnhancedCalendarScreen(),
    HealthScreen(),
    ChatScreen(),
  ];

  Map<String, dynamic>? _backendUser;
  bool _loadingUser = true;

  @override
  void initState() {
    super.initState();
    _loadBackendUser();
  }

  Future<void> _loadBackendUser() async {
    final auth = Provider.of<AuthService>(context, listen: false);

    setState(() => _loadingUser = true);

    try {
      final me = await auth.getMe();
      if (me['ok'] == true) {
        setState(() {
          _backendUser = me['data'];
        });
      }
    } catch (_) {}

    setState(() => _loadingUser = false);
  }

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthService>(context);

    final userName = _backendUser?['name'] ?? 'User';
    final userEmail = _backendUser?['email'] ?? 'No email found';
    final avatarLetter = userName.isNotEmpty ? userName[0].toUpperCase() : 'U';

    return Scaffold(
      body: _pages[_idx],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _idx,
        backgroundColor: const Color(0xFF0F0F0F),
        selectedItemColor: const Color(0xFFFF6A00),
        unselectedItemColor: Colors.grey,
        type: BottomNavigationBarType.fixed,
        onTap: (i) => setState(() => _idx = i),
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.dashboard),
            label: 'Dashboard',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.calendar_month),
            label: 'Calendar',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.monitor_heart),
            label: 'Health',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.chat_bubble_outline),
            label: 'Chat',
          ),
        ],
      ),
      drawer: Drawer(
        backgroundColor: const Color(0xFF0F0F0F),
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: const BoxDecoration(color: Color(0xFF1A1A1A)),
              child: _loadingUser
                  ? const Center(child: CircularProgressIndicator())
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        CircleAvatar(
                          radius: 26,
                          backgroundColor: const Color(0xFFFF6A00),
                          child: Text(
                            avatarLetter,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 22,
                            ),
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          userName,
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          userEmail,
                          style: const TextStyle(
                            fontSize: 13,
                            color: Colors.grey,
                          ),
                        ),
                      ],
                    ),
            ),

            // 🚪 Logout
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text('Logout'),
              onTap: () async {
                await auth.logout();

                if (context.mounted) {
                  Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => const LoginPage()),
                    (route) => false,
                  );
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}
