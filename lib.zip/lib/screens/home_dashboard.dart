import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../services/auth_service.dart'; // <-- make sure this import is correct

class HomeDashboard extends StatelessWidget {
  const HomeDashboard({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final date = DateFormat('EEE, MMM d, yyyy').format(now);

    return Scaffold(
      backgroundColor: Colors.black,

      // 🔥 LEFT SIDEBAR ADDED
      drawer: _buildSidebar(context),

      appBar: AppBar(
        backgroundColor: const Color(0xFF1A1A1A),
        elevation: 0,
        title: const Text('Doxys Dashboard'),
        centerTitle: true,
      ),

      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            Text(
              "Welcome back 👋",
              style: TextStyle(
                color: Colors.grey[400],
                fontSize: 16,
              ),
            ),
            const SizedBox(height: 4),
            const Text(
              "Your Health Overview",
              style: TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              date,
              style: const TextStyle(color: Colors.grey, fontSize: 14),
            ),
            const SizedBox(height: 20),
            GridView.count(
              crossAxisCount: 2,
              crossAxisSpacing: 14,
              mainAxisSpacing: 14,
              physics: const NeverScrollableScrollPhysics(),
              shrinkWrap: true,
              children: const [
                _DashboardCard(
                  title: "Heart Rate",
                  value: "82 bpm",
                  icon: Icons.favorite_border,
                ),
                _DashboardCard(
                  title: "Steps",
                  value: "6,540",
                  icon: Icons.directions_walk,
                ),
                _DashboardCard(
                  title: "Calories",
                  value: "1,250 kcal",
                  icon: Icons.local_fire_department,
                ),
                _DashboardCard(
                  title: "Water Intake",
                  value: "1.8 L",
                  icon: Icons.water_drop_outlined,
                ),
              ],
            ),
            const SizedBox(height: 24),
            const Text(
              "Recent Activity",
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 12),
            _ActivityTile(
              icon: Icons.fitness_center,
              title: "Morning Workout",
              time: "Today • 7:00 AM",
            ),
            _ActivityTile(
              icon: Icons.local_hospital,
              title: "Doctor Appointment",
              time: "Tomorrow • 4:30 PM",
            ),
            _ActivityTile(
              icon: Icons.nightlight_round,
              title: "Sleep Summary",
              time: "6.5 hrs last night",
            ),
          ],
        ),
      ),
    );
  }

  // ================================
  // 🔥 SIDEBAR / DRAWER FUNCTION
  // ================================
  Widget _buildSidebar(BuildContext context) {
    final auth = Provider.of<AuthService>(context, listen: false);

    return Drawer(
      backgroundColor: const Color(0xFF1A1A1A),
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 🔹 TOP: DOXYS + EMAIL
            Padding(
                padding: const EdgeInsets.all(16.0),
                child: FutureBuilder(
                  future: auth.getMe(),
                  builder: (context, snapshot) {
                    String email = "Loading...";

                    if (snapshot.connectionState == ConnectionState.done &&
                        snapshot.hasData &&
                        snapshot.data != null) {
                      // 🎯 STEP 1: Cast safely
                      final result = snapshot.data as Map<String, dynamic>;

                      // 🎯 STEP 2: Check OK
                      if (result["ok"] == true) {
                        // 🎯 STEP 3: Cast nested data also
                        final data = result["data"] as Map<String, dynamic>;

                        email = data["email"] ?? "Unknown";
                      }
                    }

                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "Doxys",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 26,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          email,
                          style: const TextStyle(color: Colors.grey),
                        ),
                      ],
                    );
                  },
                )),

            const Divider(color: Colors.grey),

            const SizedBox(height: 10),

            ListTile(
              leading: const Icon(Icons.dashboard, color: Colors.white),
              title: const Text(
                "Dashboard",
                style: TextStyle(color: Colors.white),
              ),
              onTap: () {
                Navigator.pop(context);
              },
            ),

            const Spacer(),

            // 🔥 LOGOUT BUTTON BOTTOM
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size(double.infinity, 48),
                  backgroundColor: Colors.red,
                ),
                icon: const Icon(Icons.logout),
                label: const Text("Logout"),
                onPressed: () async {
                  await auth.logout();
                  Navigator.pushReplacementNamed(context, "/login");
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DashboardCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const _DashboardCard({
    required this.title,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A1A),
        borderRadius: BorderRadius.circular(14),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: const Color(0xFFFF6A00), size: 28),
          const Spacer(),
          Text(
            value,
            style: const TextStyle(
              fontSize: 20,
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            title,
            style: const TextStyle(color: Colors.grey, fontSize: 14),
          ),
        ],
      ),
    );
  }
}

class _ActivityTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String time;

  const _ActivityTile({
    required this.icon,
    required this.title,
    required this.time,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: CircleAvatar(
        backgroundColor: const Color(0xFFFF6A00).withOpacity(0.1),
        child: Icon(icon, color: const Color(0xFFFF6A00)),
      ),
      title: Text(
        title,
        style: const TextStyle(color: Colors.white),
      ),
      subtitle: Text(
        time,
        style: const TextStyle(color: Colors.grey),
      ),
    );
  }
}
