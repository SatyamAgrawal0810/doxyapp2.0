import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:intl/intl.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import '../services/calendar_service.dart';
import '../services/auth_service.dart';
import '../services/enhanced_notification_service.dart';

class EnhancedCalendarScreen extends StatefulWidget {
  const EnhancedCalendarScreen({Key? key}) : super(key: key);

  @override
  State<EnhancedCalendarScreen> createState() => _EnhancedCalendarScreenState();
}

class _EnhancedCalendarScreenState extends State<EnhancedCalendarScreen> {
  late CalendarFormat _calendarFormat;
  DateTime _focused = DateTime.now();
  DateTime? _selected;
  final Map<DateTime, List<Map<String, dynamic>>> _events = {};
  final Map<DateTime, List<Map<String, dynamic>>> _reminders = {};
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _calendarFormat = CalendarFormat.month;
    _selected = _focused;
    _loadEvents();
    _loadReminders();
  }

  DateTime _dateOnly(DateTime d) => DateTime(d.year, d.month, d.day);

  Future<void> _loadEvents() async {
    setState(() => _loading = true);
    final auth = Provider.of<AuthService>(context, listen: false);

    final cs = CalendarService(
      baseUrl: 'https://doxy-bh96.onrender.com/api',
      auth: auth,
    );

    try {
      final data = await cs.getEvents();

      setState(() {
        _events.clear();
        for (final e in data) {
          final start =
              (DateTime.tryParse(e['start'] ?? e['startTime'] ?? '') ??
                      DateTime.now())
                  .toLocal();
          final end = (DateTime.tryParse(e['end'] ?? e['endTime'] ?? '') ??
                  start.add(const Duration(hours: 1)))
              .toLocal();

          final key = _dateOnly(start);
          _events.putIfAbsent(key, () => []).add({
            'id': e['_id'] ?? e['id'],
            'title': e['title'] ?? 'Untitled Event',
            'start': start,
            'end': end,
            'description': e['description'] ?? '',
            'location': e['location'] ?? '',
            'reminderPreferences': e['reminderPreferences'] ?? {},
          });
        }
      });
    } catch (err) {
      debugPrint('❌ Failed to load events: $err');
    } finally {
      setState(() => _loading = false);
    }
  }

  List<Map<String, dynamic>> _getEventsForDay(DateTime day) {
    return _events[_dateOnly(day)] ?? [];
  }

  List<Map<String, dynamic>> _getRemindersForDay(DateTime day) {
    return _reminders[_dateOnly(day)] ?? [];
  }

  Future<void> _createEventForSelected(Map<String, dynamic> eventData) async {
    final auth = Provider.of<AuthService>(context, listen: false);
    final cs = CalendarService(
      baseUrl: 'https://doxy-bh96.onrender.com/api',
      auth: auth,
    );

    final selectedDate = _selected ?? DateTime.now();

    // Parse the start and end date/time from the event data
    final startDate = DateTime.tryParse(eventData['startDate']) ?? selectedDate;
    final endDate = DateTime.tryParse(eventData['endDate']) ?? selectedDate;

    final startTime = DateTime(
      startDate.year,
      startDate.month,
      startDate.day,
      eventData['startHour'] ?? 0,
      eventData['startMinute'] ?? 0,
    );

    final endTime = DateTime(
      endDate.year,
      endDate.month,
      endDate.day,
      eventData['endHour'] ?? 23,
      eventData['endMinute'] ?? 59,
    );

    // Calculate reminder time
    final reminderMinutes = eventData['reminderMinutes'] ?? 15;
    final reminderTime = startTime.subtract(Duration(minutes: reminderMinutes));

    final payload = {
      "title": eventData["title"],
      "description": eventData["description"] ?? "",
      "location": eventData["location"] ?? "",

      // Required main fields
      "start": startTime.toUtc().toIso8601String(),
      "end": endTime.toUtc().toIso8601String(),
      "startTime": startTime.toUtc().toIso8601String(),
      "endTime": endTime.toUtc().toIso8601String(),

      // Backend-required defaults
      "isAllDay": eventData["isAllDay"] ?? false,
      "attendees": eventData["attendees"] ?? [],
      "colorId": eventData["colorId"] ?? "1",

      // Reminders configuration
      "reminders": {
        "useDefault": false,
        "overrides": [
          {
            "method": "popup",
            "minutes": reminderMinutes,
          }
        ]
      },

      // Enhanced reminder preferences with voice support
      "reminderPreferences": {
        "enabled": eventData["notificationEnabled"] ?? true,
        "minutesBefore": reminderMinutes,
        "type": eventData["reminderType"] ?? "event",
        "priority": eventData["reminderPriority"] ?? "medium",
        "notificationMethods": {
          "push": eventData["pushEnabled"] ?? true,
          "voice": eventData["voiceEnabled"] ?? false,
          "email": eventData["emailEnabled"] ?? false,
        },
        "voiceSettings": {
          "enabled": eventData["voiceEnabled"] ?? false,
          "tone": eventData["voiceTone"] ?? "friendly",
          "language": eventData["voiceLanguage"] ?? "hi-IN",
          "customMessage": eventData["voiceCustomMessage"] ?? "",
        },
        "tags": eventData["tags"] ?? ["event"],
      }
    };

    final res = await cs.createEvent(payload);

    if (res['status'] == 201 || res['status'] == 200) {
      // Schedule local notification if enabled
      if (eventData['notificationEnabled'] == true &&
          reminderTime.isAfter(DateTime.now())) {
        await EnhancedNotificationService.scheduleUltraHighPriorityNotification(
          title: '📅 ${eventData['title']}',
          body: 'Your event starts in $reminderMinutes minutes',
          scheduledTime: reminderTime,
          eventId: res['body']['_id'] ??
              res['body']['id'] ??
              DateTime.now().toString(),
        );

        // If voice is enabled, also schedule a voice notification
        if (eventData['voiceEnabled'] == true) {
          debugPrint(
              '🎤 Voice notification will be triggered at reminder time');
        }
      }

      await _loadEvents();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content:
                Text('✅ Event "${eventData['title']}" created successfully!'),
            backgroundColor: const Color(0xFF4CAF50),
            duration: const Duration(seconds: 2),
          ),
        );
      }
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('❌ Failed to create event: ${res['body']}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _createReminderForSelected(Map<String, dynamic> remData) async {
    final auth = Provider.of<AuthService>(context, listen: false);
    final cs = CalendarService(
      baseUrl: 'https://doxy-bh96.onrender.com/api',
      auth: auth,
    );

    final selectedDate = _selected ?? DateTime.now();

    final remDate = DateTime.tryParse(remData['date']) ?? selectedDate;
    final hour = remData['hour'] ?? 0;
    final minute = remData['minute'] ?? 0;

    final scheduled = DateTime(
      remDate.year,
      remDate.month,
      remDate.day,
      hour,
      minute,
    );

    // --- BACKEND PAYLOAD (MATCHES YOUR EXPRESS VALIDATION) ---
    final payload = {
      "title": remData["title"],
      "description": remData["description"] ?? "",
      "reminderTime": scheduled.toUtc().toIso8601String(),
      "type": "custom",
      "priority": "medium",
    };

    final res = await cs.createReminder(payload);

    if (res['status'] == 201 || res['status'] == 200) {
      final saved = res['body']['reminder'] ?? res['body'];

      final id = saved['_id'] ?? saved['id'];

      // Add to local UI
      final key = _dateOnly(scheduled);
      setState(() {
        _reminders.putIfAbsent(key, () => []).add({
          'id': id,
          'title': payload['title'],
          'description': payload['description'],
          'time': scheduled,
        });
      });

      // Local notification
      if ((remData['notificationEnabled'] ?? true) &&
          scheduled.isAfter(DateTime.now())) {
        await EnhancedNotificationService.scheduleUltraHighPriorityNotification(
          title: "🔔 ${payload['title']}",
          body: payload['description'] ?? "",
          scheduledTime: scheduled,
          eventId: id,
        );
      }

      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text("✅ Reminder created"),
        backgroundColor: Color(0xFF4CAF50),
      ));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("❌ Reminder create failed: ${res['body']}"),
        backgroundColor: Colors.red,
      ));
    }
  }

  Future<void> _loadReminders() async {
    final auth = Provider.of<AuthService>(context, listen: false);
    final cs = CalendarService(
      baseUrl: 'https://doxy-bh96.onrender.com/api',
      auth: auth,
    );

    try {
      final data = await cs.getReminders();

      setState(() {
        _reminders.clear();

        for (final r in data) {
          final time = DateTime.parse(r['reminderTime']).toLocal();
          final key = _dateOnly(time);

          _reminders.putIfAbsent(key, () => []).add({
            'id': r['_id'],
            'title': r['title'],
            'description': r['description'] ?? '',
            'time': time,
          });
        }
      });
    } catch (e) {
      debugPrint("❌ Reminder load error: $e");
    }
  }

  Future<void> _deleteReminder(String id) async {
    final auth = Provider.of<AuthService>(context, listen: false);
    final cs = CalendarService(
      baseUrl: 'https://doxy-bh96.onrender.com/api',
      auth: auth,
    );

    final ok = await cs.deleteReminder(id);

    if (ok) {
      await EnhancedNotificationService.cancelEventNotification(id);

      await _loadReminders();

      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text("🗑️ Reminder deleted"),
        backgroundColor: Color(0xFF757575),
      ));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text("❌ Reminder delete failed"),
        backgroundColor: Colors.red,
      ));
    }
  }

  Future<void> _deleteEvent(String id) async {
    final auth = Provider.of<AuthService>(context, listen: false);
    final cs = CalendarService(
      baseUrl: 'https://doxy-bh96.onrender.com/api',
      auth: auth,
    );

    final ok = await cs.deleteEvent(id);
    if (ok) {
      // Cancel any scheduled notifications for this event
      await EnhancedNotificationService.cancelEventNotification(id);

      await _loadEvents();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('🗑️ Event deleted'),
            backgroundColor: Color(0xFF757575),
          ),
        );
      }
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('❌ Delete failed'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final eventsForSelected = _getEventsForDay(_selected ?? _focused);
    final remindersForSelected = _getRemindersForDay(_selected ?? _focused);

    return Scaffold(
      appBar: AppBar(
        title: const Text('📅 Calendar'),
        backgroundColor: const Color(0xFF1A1A1A),
        centerTitle: true,
        elevation: 0,
      ),
      backgroundColor: Colors.black,
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFFFF6A00)),
            )
          : Column(
              children: [
                // Calendar Widget
                Container(
                  margin: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1A1A1A),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: const Color(0xFF333333)),
                  ),
                  child: TableCalendar(
                    focusedDay: _focused,
                    firstDay: DateTime.utc(2000, 1, 1),
                    lastDay: DateTime.utc(2100, 12, 31),
                    calendarFormat: _calendarFormat,
                    selectedDayPredicate: (d) =>
                        _dateOnly(d) == _dateOnly(_selected ?? _focused),
                    onDaySelected: (selected, focused) {
                      setState(() {
                        _selected = selected;
                        _focused = focused;
                      });
                    },
                    onFormatChanged: (f) => setState(() => _calendarFormat = f),
                    eventLoader: (day) => _getEventsForDay(day),
                    calendarStyle: const CalendarStyle(
                      markerDecoration: BoxDecoration(
                        color: Color(0xFFFF6A00),
                        shape: BoxShape.circle,
                      ),
                      selectedDecoration: BoxDecoration(
                        color: Color(0xFFFF6A00),
                        shape: BoxShape.circle,
                      ),
                      todayDecoration: BoxDecoration(
                        color: Color(0x44FF6A00),
                        shape: BoxShape.circle,
                      ),
                      weekendTextStyle: TextStyle(color: Colors.grey),
                      defaultTextStyle: TextStyle(color: Colors.white),
                      outsideTextStyle: TextStyle(color: Colors.grey),
                    ),
                    headerStyle: const HeaderStyle(
                      titleTextStyle: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                      formatButtonDecoration: BoxDecoration(
                        color: Color(0xFFFF6A00),
                        borderRadius: BorderRadius.all(Radius.circular(12)),
                      ),
                      formatButtonTextStyle: TextStyle(color: Colors.white),
                      leftChevronIcon:
                          Icon(Icons.chevron_left, color: Color(0xFFFF6A00)),
                      rightChevronIcon:
                          Icon(Icons.chevron_right, color: Color(0xFFFF6A00)),
                    ),
                  ),
                ),

                const SizedBox(height: 10),

                // Single Row: Selected Date (left) + Add Event + Add Reminder (right)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      // Left: Selected Date in "DD MMM YYYY"
                      Text(
                        DateFormat('dd MMM yyyy').format(_selected ?? _focused),
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),

                      const Spacer(),

                      // Right: Buttons in same line
                      Row(
                        children: [
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFFFF6A00),
                              foregroundColor: Colors.white,
                              elevation: 2,
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 14, vertical: 8),
                            ),
                            onPressed: () async {
                              final eventData = await _showCreateEventDialog();
                              if (eventData != null) {
                                await _createEventForSelected(eventData);
                              }
                            },
                            child: const Text('Add Event'),
                          ),
                          const SizedBox(width: 8),
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF333333),
                              foregroundColor: Colors.white,
                              elevation: 0,
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 14, vertical: 8),
                            ),
                            onPressed: () async {
                              final remData = await _showCreateReminderDialog();
                              if (remData != null) {
                                await _createReminderForSelected(remData);
                              }
                            },
                            child: const Text('Add Reminder'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 12),

                // Combined Events + Reminders list
                Expanded(
                  child: (eventsForSelected.isEmpty &&
                          remindersForSelected.isEmpty)
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.calendar_today_outlined,
                                size: 64,
                                color: Colors.grey[700],
                              ),
                              const SizedBox(height: 16),
                              Text(
                                'No events or reminders',
                                style: TextStyle(
                                  color: Colors.grey[600],
                                  fontSize: 16,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'Use the buttons above to add an event or reminder',
                                style: TextStyle(
                                  color: Colors.grey[700],
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                        )
                      : ListView(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 8),
                          children: [
                            // Events section (each event shows: name, time, description)
                            if (eventsForSelected.isNotEmpty) ...[
                              const SizedBox(height: 6),
                              Row(
                                children: [
                                  Icon(Icons.event, color: Color(0xFFFF6A00)),
                                  const SizedBox(width: 8),
                                  Text(
                                    'Events',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              ...eventsForSelected.map((ev) {
                                final id = ev['id'] ?? '';
                                final title = ev['title'] ?? 'Untitled';
                                final start = ev['start'] as DateTime;
                                final end = ev['end'] as DateTime;
                                final description = ev['description'] ?? '';
                                final location = ev['location'] ?? '';

                                return Padding(
                                  padding: const EdgeInsets.only(bottom: 8),
                                  child: Slidable(
                                    key: ValueKey(id),
                                    endActionPane: ActionPane(
                                      motion: const ScrollMotion(),
                                      children: [
                                        SlidableAction(
                                          onPressed: (_) => _deleteEvent(id),
                                          backgroundColor: Colors.red[600]!,
                                          foregroundColor: Colors.white,
                                          icon: Icons.delete_outline,
                                          label: 'Delete',
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                      ],
                                    ),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        gradient: const LinearGradient(
                                          colors: [
                                            Color(0xFF1A1A1A),
                                            Color(0xFF252525),
                                          ],
                                          begin: Alignment.topLeft,
                                          end: Alignment.bottomRight,
                                        ),
                                        borderRadius: BorderRadius.circular(12),
                                        border: Border.all(
                                          color: const Color(0xFF333333),
                                          width: 0.5,
                                        ),
                                      ),
                                      child: ListTile(
                                        contentPadding:
                                            const EdgeInsets.all(16),
                                        leading: Container(
                                          width: 4,
                                          height: 50,
                                          decoration: BoxDecoration(
                                            color: const Color(0xFFFF6A00),
                                            borderRadius:
                                                BorderRadius.circular(2),
                                          ),
                                        ),
                                        title: Text(
                                          title,
                                          style: const TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.w600,
                                            fontSize: 16,
                                          ),
                                        ),
                                        subtitle: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            const SizedBox(height: 4),
                                            Row(
                                              children: [
                                                const Icon(
                                                  Icons.access_time,
                                                  size: 14,
                                                  color: Color(0xFFFF6A00),
                                                ),
                                                const SizedBox(width: 4),
                                                Text(
                                                  '${DateFormat('hh:mm a').format(start)} - ${DateFormat('hh:mm a').format(end)}',
                                                  style: const TextStyle(
                                                    color: Colors.grey,
                                                    fontSize: 14,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            if (location.isNotEmpty) ...[
                                              const SizedBox(height: 4),
                                              Row(
                                                children: [
                                                  const Icon(
                                                    Icons.location_on,
                                                    size: 14,
                                                    color: Color(0xFFFF6A00),
                                                  ),
                                                  const SizedBox(width: 4),
                                                  Expanded(
                                                    child: Text(
                                                      location,
                                                      style: TextStyle(
                                                        color: Colors.grey[400],
                                                        fontSize: 13,
                                                      ),
                                                      maxLines: 1,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ],
                                            if (description.isNotEmpty) ...[
                                              const SizedBox(height: 6),
                                              Text(
                                                description,
                                                style: TextStyle(
                                                  color: Colors.grey[400],
                                                  fontSize: 13,
                                                ),
                                                maxLines: 2,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                            ],
                                          ],
                                        ),
                                        trailing: Icon(
                                          Icons.chevron_right,
                                          color: Colors.grey[600],
                                        ),
                                      ),
                                    ),
                                  ),
                                );
                              }).toList(),
                            ],

                            // Reminders section (each reminder shows: Reminder, title, time, description)
                            if (remindersForSelected.isNotEmpty) ...[
                              const SizedBox(height: 10),
                              Row(
                                children: [
                                  Icon(Icons.notifications,
                                      color: Color(0xFFFF6A00)),
                                  const SizedBox(width: 8),
                                  Text(
                                    'Reminders',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              ...remindersForSelected.map((rem) {
                                final id = rem['id'] ?? '';
                                final title =
                                    rem['title'] ?? 'Untitled Reminder';
                                final time = rem['time'] as DateTime;
                                final description = rem['description'] ?? '';

                                return Padding(
                                  padding: const EdgeInsets.only(bottom: 8),
                                  child: Slidable(
                                    key: ValueKey(id),
                                    endActionPane: ActionPane(
                                      motion: const ScrollMotion(),
                                      children: [
                                        SlidableAction(
                                          onPressed: (_) => _deleteReminder(id),
                                          backgroundColor: Colors.red,
                                          foregroundColor: Colors.white,
                                          icon: Icons.delete,
                                          label: 'Delete',
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                      ],
                                    ),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: const Color(0xFF111111),
                                        borderRadius: BorderRadius.circular(12),
                                        border: Border.all(
                                            color: const Color(0xFF333333)),
                                      ),
                                      child: ListTile(
                                        contentPadding:
                                            const EdgeInsets.all(16),
                                        leading: Container(
                                          width: 4,
                                          height: 50,
                                          decoration: BoxDecoration(
                                            color: const Color(0xFFFF6A00),
                                            borderRadius:
                                                BorderRadius.circular(2),
                                          ),
                                        ),
                                        title: Text(
                                          title,
                                          style: const TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.w600,
                                            fontSize: 15,
                                          ),
                                        ),
                                        subtitle: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            const SizedBox(height: 6),
                                            Row(
                                              children: [
                                                const Icon(Icons.access_time,
                                                    size: 14,
                                                    color: Color(0xFFFF6A00)),
                                                const SizedBox(width: 6),
                                                Text(
                                                  DateFormat('hh:mm a')
                                                      .format(time),
                                                  style: const TextStyle(
                                                      color: Colors.grey,
                                                      fontSize: 14),
                                                ),
                                              ],
                                            ),
                                            if (description.isNotEmpty) ...[
                                              const SizedBox(height: 8),
                                              Text(
                                                description,
                                                style: TextStyle(
                                                    color: Colors.grey[400],
                                                    fontSize: 13),
                                              ),
                                            ],
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                );
                              }).toList(),
                            ],
                          ],
                        ),
                ),
              ],
            ),
    );
  }

  Future<Map<String, dynamic>?> _showCreateEventDialog() {
    final titleController = TextEditingController();
    final descriptionController = TextEditingController();
    final locationController = TextEditingController();
    final voiceMessageController = TextEditingController();

    // Default times and dates
    final now = DateTime.now();
    final selectedDate = _selected ?? now;

    String startDate = DateFormat('yyyy-MM-dd').format(selectedDate);
    String endDate = DateFormat('yyyy-MM-dd').format(selectedDate);

    int startHour = now.hour;
    int startMinute = now.minute;
    int endHour = now.hour + 1;
    int endMinute = now.minute;

    bool notificationEnabled = true;
    bool voiceEnabled = false;
    bool pushEnabled = true;
    bool emailEnabled = false;

    int reminderMinutes = 15;
    String reminderType = 'event';
    String reminderPriority = 'medium';
    String voiceTone = 'friendly';
    String voiceLanguage = 'hi-IN';

    return showDialog<Map<String, dynamic>>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              backgroundColor: const Color(0xFF1A1A1A),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              title: Row(
                children: [
                  const Icon(Icons.event_note, color: Color(0xFFFF6A00)),
                  const SizedBox(width: 8),
                  const Text(
                    'Create New Event',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                ],
              ),
              content: Container(
                width: double.maxFinite,
                constraints: BoxConstraints(
                    maxHeight: MediaQuery.of(context).size.height * 0.7),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Title Field
                      _buildSectionHeader('📝 Event Details'),
                      const SizedBox(height: 12),
                      TextField(
                        controller: titleController,
                        style: const TextStyle(color: Colors.white),
                        decoration: InputDecoration(
                          labelText: 'Event Title *',
                          labelStyle: TextStyle(color: Colors.grey[400]),
                          hintText: 'e.g., Doctor Appointment',
                          hintStyle: TextStyle(color: Colors.grey[600]),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.grey[600]!),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide:
                                const BorderSide(color: Color(0xFFFF6A00)),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          prefixIcon:
                              Icon(Icons.title, color: Colors.grey[400]),
                        ),
                      ),
                      const SizedBox(height: 12),

                      // Description Field
                      TextField(
                        controller: descriptionController,
                        style: const TextStyle(color: Colors.white),
                        maxLines: 2,
                        decoration: InputDecoration(
                          labelText: 'Description',
                          labelStyle: TextStyle(color: Colors.grey[400]),
                          hintText: 'Add details about the event',
                          hintStyle: TextStyle(color: Colors.grey[600]),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.grey[600]!),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide:
                                const BorderSide(color: Color(0xFFFF6A00)),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          prefixIcon:
                              Icon(Icons.description, color: Colors.grey[400]),
                        ),
                      ),
                      const SizedBox(height: 12),

                      // Location Field
                      TextField(
                        controller: locationController,
                        style: const TextStyle(color: Colors.white),
                        decoration: InputDecoration(
                          labelText: 'Location',
                          labelStyle: TextStyle(color: Colors.grey[400]),
                          hintText: 'Where will this event take place?',
                          hintStyle: TextStyle(color: Colors.grey[600]),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.grey[600]!),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide:
                                const BorderSide(color: Color(0xFFFF6A00)),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          prefixIcon:
                              Icon(Icons.location_on, color: Colors.grey[400]),
                        ),
                      ),
                      const SizedBox(height: 20),

                      // Date & Time Section
                      _buildSectionHeader('📅 Date & Time'),
                      const SizedBox(height: 12),

                      // Start Date
                      _buildDateTimePicker(
                        label: 'Start Date',
                        icon: Icons.calendar_today,
                        value: startDate,
                        onTap: () async {
                          final picked = await showDatePicker(
                            context: context,
                            initialDate: DateTime.parse(startDate),
                            firstDate: DateTime(2000),
                            lastDate: DateTime(2100),
                            builder: (context, child) {
                              return Theme(
                                data: Theme.of(context).copyWith(
                                  colorScheme: const ColorScheme.dark(
                                    primary: Color(0xFFFF6A00),
                                  ),
                                ),
                                child: child!,
                              );
                            },
                          );
                          if (picked != null) {
                            setState(() {
                              startDate =
                                  DateFormat('yyyy-MM-dd').format(picked);
                            });
                          }
                        },
                      ),

                      const SizedBox(height: 12),

                      // End Date
                      _buildDateTimePicker(
                        label: 'End Date',
                        icon: Icons.event,
                        value: endDate,
                        onTap: () async {
                          final picked = await showDatePicker(
                            context: context,
                            initialDate: DateTime.parse(endDate),
                            firstDate: DateTime.parse(startDate),
                            lastDate: DateTime(2100),
                            builder: (context, child) {
                              return Theme(
                                data: Theme.of(context).copyWith(
                                  colorScheme: const ColorScheme.dark(
                                    primary: Color(0xFFFF6A00),
                                  ),
                                ),
                                child: child!,
                              );
                            },
                          );
                          if (picked != null) {
                            setState(() {
                              endDate = DateFormat('yyyy-MM-dd').format(picked);
                            });
                          }
                        },
                      ),

                      const SizedBox(height: 12),

                      // Start Time
                      Row(
                        children: [
                          const Icon(Icons.play_arrow,
                              color: Color(0xFFFF6A00), size: 20),
                          const SizedBox(width: 8),
                          Text('Start Time:',
                              style: TextStyle(color: Colors.grey[300])),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 8),
                              decoration: BoxDecoration(
                                color: const Color(0xFF252525),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: GestureDetector(
                                onTap: () async {
                                  final time = await showTimePicker(
                                    context: context,
                                    initialTime: TimeOfDay(
                                        hour: startHour, minute: startMinute),
                                    builder: (context, child) {
                                      return Theme(
                                        data: Theme.of(context).copyWith(
                                          colorScheme: const ColorScheme.dark(
                                            primary: Color(0xFFFF6A00),
                                          ),
                                        ),
                                        child: child!,
                                      );
                                    },
                                  );
                                  if (time != null) {
                                    setState(() {
                                      startHour = time.hour;
                                      startMinute = time.minute;
                                      if (endHour <= startHour) {
                                        endHour = startHour + 1;
                                        endMinute = startMinute;
                                      }
                                    });
                                  }
                                },
                                child: Text(
                                  '${startHour.toString().padLeft(2, '0')}:${startMinute.toString().padLeft(2, '0')}',
                                  style: const TextStyle(
                                      color: Colors.white, fontSize: 16),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 12),

                      // End Time
                      Row(
                        children: [
                          const Icon(Icons.stop,
                              color: Color(0xFFFF6A00), size: 20),
                          const SizedBox(width: 8),
                          Text('End Time:',
                              style: TextStyle(color: Colors.grey[300])),
                          const SizedBox(width: 22),
                          Expanded(
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 8),
                              decoration: BoxDecoration(
                                color: const Color(0xFF252525),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: GestureDetector(
                                onTap: () async {
                                  final time = await showTimePicker(
                                    context: context,
                                    initialTime: TimeOfDay(
                                        hour: endHour, minute: endMinute),
                                    builder: (context, child) {
                                      return Theme(
                                        data: Theme.of(context).copyWith(
                                          colorScheme: const ColorScheme.dark(
                                            primary: Color(0xFFFF6A00),
                                          ),
                                        ),
                                        child: child!,
                                      );
                                    },
                                  );
                                  if (time != null) {
                                    setState(() {
                                      endHour = time.hour;
                                      endMinute = time.minute;
                                    });
                                  }
                                },
                                child: Text(
                                  '${endHour.toString().padLeft(2, '0')}:${endMinute.toString().padLeft(2, '0')}',
                                  style: const TextStyle(
                                      color: Colors.white, fontSize: 16),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 20),

                      // Reminder Section
                      _buildSectionHeader('🔔 Reminder Settings'),
                      const SizedBox(height: 12),

                      // Reminder Type
                      _buildDropdown(
                        label: 'Reminder Type',
                        value: reminderType,
                        items: {
                          'event': '📅 Event',
                          'medication': '💊 Medication',
                          'task': '✅ Task',
                          'appointment': '🏥 Appointment',
                          'meeting': '👥 Meeting',
                        },
                        onChanged: (v) => setState(() => reminderType = v!),
                      ),

                      const SizedBox(height: 12),

                      // Reminder Priority
                      _buildDropdown(
                        label: 'Priority',
                        value: reminderPriority,
                        items: {
                          'low': '🟢 Low',
                          'medium': '🔵 Medium',
                          'high': '🟠 High',
                          'urgent': '🔴 Urgent',
                        },
                        onChanged: (v) => setState(() => reminderPriority = v!),
                      ),

                      const SizedBox(height: 12),

                      // Reminder Time
                      _buildDropdown(
                        label: 'Remind me',
                        value: reminderMinutes.toString(),
                        items: {
                          '2': '2 minutes before',
                          '5': '5 minutes before',
                          '10': '10 minutes before',
                          '15': '15 minutes before',
                          '30': '30 minutes before',
                          '60': '1 hour before',
                          '120': '2 hours before',
                        },
                        onChanged: (v) =>
                            setState(() => reminderMinutes = int.parse(v!)),
                      ),

                      const SizedBox(height: 20),

                      // Notification Methods
                      _buildSectionHeader('📱 Notification Methods'),
                      const SizedBox(height: 12),

                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: const Color(0xFF252525),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Column(
                          children: [
                            _buildSwitch(
                              title: '📱 Push Notification',
                              value: pushEnabled,
                              onChanged: (v) => setState(() => pushEnabled = v),
                            ),
                            _buildSwitch(
                              title: '🎤 Voice Notification',
                              value: voiceEnabled,
                              onChanged: (v) =>
                                  setState(() => voiceEnabled = v),
                            ),
                            _buildSwitch(
                              title: '📧 Email Notification',
                              value: emailEnabled,
                              onChanged: (v) =>
                                  setState(() => emailEnabled = v),
                            ),
                          ],
                        ),
                      ),

                      if (voiceEnabled) ...[
                        const SizedBox(height: 20),
                        _buildSectionHeader('🎤 Voice Settings'),
                        const SizedBox(height: 12),
                        _buildDropdown(
                          label: 'Voice Tone',
                          value: voiceTone,
                          items: {
                            'friendly': '😊 Friendly',
                            'urgent': '⚡ Urgent',
                            'calm': '😌 Calm',
                            'energetic': '🚀 Energetic',
                          },
                          onChanged: (v) => setState(() => voiceTone = v!),
                        ),
                        const SizedBox(height: 12),
                        _buildDropdown(
                          label: 'Language',
                          value: voiceLanguage,
                          items: {
                            'hi-IN': '🇮🇳 Hindi',
                            'en-US': '🇺🇸 English',
                            'en-IN': '🇮🇳 English (India)',
                          },
                          onChanged: (v) => setState(() => voiceLanguage = v!),
                        ),
                        const SizedBox(height: 12),
                        TextField(
                          controller: voiceMessageController,
                          style: const TextStyle(color: Colors.white),
                          decoration: InputDecoration(
                            labelText: 'Custom Voice Message',
                            labelStyle: TextStyle(color: Colors.grey[400]),
                            hintText: 'Optional custom message',
                            hintStyle: TextStyle(color: Colors.grey[600]),
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.grey[600]!),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: Color(0xFFFF6A00)),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            prefixIcon:
                                Icon(Icons.mic, color: Colors.grey[400]),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text(
                    'Cancel',
                    style: TextStyle(color: Colors.grey),
                  ),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFFF6A00),
                    foregroundColor: Colors.white,
                  ),
                  onPressed: () {
                    if (titleController.text.trim().isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Please enter event title'),
                          backgroundColor: Colors.red,
                        ),
                      );
                      return;
                    }

                    // Validate times
                    final startDateTime =
                        DateTime(2024, 1, 1, startHour, startMinute);
                    final endDateTime =
                        DateTime(2024, 1, 1, endHour, endMinute);

                    if (endDateTime.isBefore(startDateTime)) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('End time must be after start time'),
                          backgroundColor: Colors.red,
                        ),
                      );
                      return;
                    }

                    Navigator.of(context).pop({
                      'title': titleController.text.trim(),
                      'description': descriptionController.text.trim(),
                      'location': locationController.text.trim(),
                      'startDate': startDate,
                      'endDate': endDate,
                      'startHour': startHour,
                      'startMinute': startMinute,
                      'endHour': endHour,
                      'endMinute': endMinute,
                      'notificationEnabled': notificationEnabled,
                      'reminderMinutes': reminderMinutes,
                      'reminderType': reminderType,
                      'reminderPriority': reminderPriority,
                      'pushEnabled': pushEnabled,
                      'voiceEnabled': voiceEnabled,
                      'emailEnabled': emailEnabled,
                      'voiceTone': voiceTone,
                      'voiceLanguage': voiceLanguage,
                      'voiceCustomMessage': voiceMessageController.text.trim(),
                      'tags': [reminderType, 'calendar'],
                    });
                  },
                  child: const Text('Create Event'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<Map<String, dynamic>?> _showCreateReminderDialog() {
    final titleController = TextEditingController();
    final descriptionController = TextEditingController();

    final now = DateTime.now();
    final selectedDate = _selected ?? now;

    String dateStr = DateFormat('yyyy-MM-dd').format(selectedDate);
    int hour = now.hour;
    int minute = now.minute;

    bool notificationEnabled = true;

    return showDialog<Map<String, dynamic>>(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return StatefulBuilder(builder: (context, setState) {
          return AlertDialog(
            backgroundColor: const Color(0xFF1A1A1A),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            title: Row(
              children: const [
                Icon(Icons.notifications, color: Color(0xFFFF6A00)),
                SizedBox(width: 8),
                Text(
                  'Create Reminder',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold),
                ),
              ],
            ),
            content: Container(
              width: double.maxFinite,
              constraints: BoxConstraints(
                  maxHeight: MediaQuery.of(context).size.height * 0.5),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextField(
                      controller: titleController,
                      style: const TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                        labelText: 'Title *',
                        labelStyle: TextStyle(color: Colors.grey[400]),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.grey[600]!),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Color(0xFFFF6A00)),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        prefixIcon: Icon(Icons.title, color: Colors.grey[400]),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: descriptionController,
                      style: const TextStyle(color: Colors.white),
                      maxLines: 2,
                      decoration: InputDecoration(
                        labelText: 'Description',
                        labelStyle: TextStyle(color: Colors.grey[400]),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.grey[600]!),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Color(0xFFFF6A00)),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        prefixIcon:
                            Icon(Icons.description, color: Colors.grey[400]),
                      ),
                    ),
                    const SizedBox(height: 12),
                    GestureDetector(
                      onTap: () async {
                        final picked = await showDatePicker(
                          context: context,
                          initialDate: DateTime.parse(dateStr),
                          firstDate: DateTime(2000),
                          lastDate: DateTime(2100),
                          builder: (context, child) {
                            return Theme(
                              data: Theme.of(context).copyWith(
                                colorScheme: const ColorScheme.dark(
                                  primary: Color(0xFFFF6A00),
                                ),
                              ),
                              child: child!,
                            );
                          },
                        );
                        if (picked != null) {
                          setState(() {
                            dateStr = DateFormat('yyyy-MM-dd').format(picked);
                          });
                        }
                      },
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: const Color(0xFF252525),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.grey[600]!),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.calendar_today,
                                color: Color(0xFFFF6A00)),
                            const SizedBox(width: 12),
                            Text('Date',
                                style: TextStyle(color: Colors.grey[300])),
                            const Spacer(),
                            Text(dateStr,
                                style: const TextStyle(color: Colors.white)),
                            const SizedBox(width: 8),
                            const Icon(Icons.arrow_drop_down,
                                color: Colors.grey),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    GestureDetector(
                      onTap: () async {
                        final time = await showTimePicker(
                          context: context,
                          initialTime: TimeOfDay(hour: hour, minute: minute),
                          builder: (context, child) {
                            return Theme(
                              data: Theme.of(context).copyWith(
                                colorScheme: const ColorScheme.dark(
                                  primary: Color(0xFFFF6A00),
                                ),
                              ),
                              child: child!,
                            );
                          },
                        );
                        if (time != null) {
                          setState(() {
                            hour = time.hour;
                            minute = time.minute;
                          });
                        }
                      },
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: const Color(0xFF252525),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.grey[600]!),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.access_time,
                                color: Color(0xFFFF6A00)),
                            const SizedBox(width: 12),
                            Text('Time',
                                style: TextStyle(color: Colors.grey[300])),
                            const Spacer(),
                            Text(
                                '${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}',
                                style: const TextStyle(color: Colors.white)),
                            const SizedBox(width: 8),
                            const Icon(Icons.arrow_drop_down,
                                color: Colors.grey),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        const Expanded(
                            child: Text('Send notification',
                                style: TextStyle(color: Colors.white))),
                        Switch(
                          value: notificationEnabled,
                          activeColor: const Color(0xFFFF6A00),
                          onChanged: (v) =>
                              setState(() => notificationEnabled = v),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child:
                    const Text('Cancel', style: TextStyle(color: Colors.grey)),
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFFF6A00)),
                onPressed: () {
                  if (titleController.text.trim().isEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                          content: Text('Please enter reminder title'),
                          backgroundColor: Colors.red),
                    );
                    return;
                  }

                  Navigator.of(context).pop({
                    'title': titleController.text.trim(),
                    'description': descriptionController.text.trim(),
                    'date': dateStr,
                    'hour': hour,
                    'minute': minute,
                    'notificationEnabled': notificationEnabled,
                  });
                },
                child: const Text('Create Reminder'),
              ),
            ],
          );
        });
      },
    );
  }

  Widget _buildSectionHeader(String title) {
    return Text(
      title,
      style: const TextStyle(
        color: Color(0xFFFF6A00),
        fontWeight: FontWeight.w600,
        fontSize: 16,
      ),
    );
  }

  Widget _buildDateTimePicker({
    required String label,
    required IconData icon,
    required String value,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xFF252525),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.grey[600]!),
        ),
        child: Row(
          children: [
            Icon(icon, color: const Color(0xFFFF6A00)),
            const SizedBox(width: 12),
            Text(
              label,
              style: TextStyle(color: Colors.grey[300]),
            ),
            const Spacer(),
            Text(
              value,
              style: const TextStyle(
                  color: Colors.white, fontWeight: FontWeight.w500),
            ),
            const SizedBox(width: 8),
            const Icon(Icons.arrow_drop_down, color: Colors.grey),
          ],
        ),
      ),
    );
  }

  Widget _buildDropdown({
    required String label,
    required String value,
    required Map<String, String> items,
    required Function(String?) onChanged,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(color: Colors.grey[400], fontSize: 14),
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            color: const Color(0xFF252525),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Colors.grey[600]!),
          ),
          child: DropdownButton<String>(
            value: value,
            isExpanded: true,
            dropdownColor: const Color(0xFF1A1A1A),
            underline: const SizedBox(),
            style: const TextStyle(color: Colors.white),
            items: items.entries
                .map((e) => DropdownMenuItem(
                      value: e.key,
                      child: Text(e.value),
                    ))
                .toList(),
            onChanged: onChanged,
          ),
        ),
      ],
    );
  }

  Widget _buildSwitch({
    required String title,
    required bool value,
    required Function(bool) onChanged,
  }) {
    return Row(
      children: [
        Expanded(
          child: Text(
            title,
            style: const TextStyle(color: Colors.white),
          ),
        ),
        Switch(
          value: value,
          activeColor: const Color(0xFFFF6A00),
          onChanged: (v) => onChanged(v),
        ),
      ],
    );
  }
}
