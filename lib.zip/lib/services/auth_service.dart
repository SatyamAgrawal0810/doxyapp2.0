import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:app_links/app_links.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

class AuthService extends ChangeNotifier {
  /// BACKEND URL
  static const String API_BASE_URL = "https://doxy-bh96.onrender.com/api/auth";

  final FlutterSecureStorage _storage = const FlutterSecureStorage();
  final AppLinks _appLinks = AppLinks();

  String? token;
  bool isLoading = false;
  bool _isSendingDeviceToken = false; // Prevent double-send spam

  AuthService() {
    _loadToken();
    _initDeepLinkListener();
    _initFCMListeners();
  }

  // ============================================================
  // 🔗 GOOGLE OAUTH DEEP LINK HANDLER
  // ============================================================
  void _initDeepLinkListener() {
    _appLinks.uriLinkStream.listen((uri) async {
      if (uri == null) return;

      debugPrint("🔗 Deep Link Received: $uri");

      final jwt = uri.queryParameters["token"];
      if (jwt != null && jwt.isNotEmpty) {
        await saveToken(jwt);
        debugPrint("🔥 Google OAuth Success — JWT Saved");
      }
    });
  }

  // ============================================================
  // 🔥 FCM TOKEN LISTENERS (startup + refresh)
  // ============================================================
  void _initFCMListeners() {
    /// Startup FCM token
    FirebaseMessaging.instance.getToken().then((t) async {
      debugPrint("📡 FCM Startup Token: $t");

      if (t != null && isAuthenticated) {
        await sendDeviceTokenToServer();
      }
    });

    /// Token refresh
    FirebaseMessaging.instance.onTokenRefresh.listen((newToken) async {
      debugPrint("🔁 FCM Token Refreshed: $newToken");

      if (isAuthenticated) {
        await sendDeviceTokenToServer();
      }
    });
  }

  // ============================================================
  // 🔑 TOKEN HANDLING
  // ============================================================
  Future<void> _loadToken() async {
    token = await _storage.read(key: "jwt_token");

    notifyListeners();

    if (token != null) {
      await sendDeviceTokenToServer();
    }
  }

  Future<void> saveToken(String t) async {
    token = t;
    await _storage.write(key: "jwt_token", value: t);

    notifyListeners();

    await sendDeviceTokenToServer(); // Auto sync device token
  }

  Future<void> removeToken() async {
    token = null;
    await _storage.delete(key: "jwt_token");

    notifyListeners();
  }

  Map<String, String> _headers() {
    return {
      "Content-Type": "application/json",
      if (token != null) "Authorization": "Bearer $token",
    };
  }

  bool get isAuthenticated => token != null && token!.isNotEmpty;

  // ============================================================
  // 📡 SEND FCM DEVICE TOKEN TO BACKEND
  // ============================================================
  Future<void> sendDeviceTokenToServer() async {
    if (_isSendingDeviceToken) return; // prevent spam
    _isSendingDeviceToken = true;

    try {
      if (!isAuthenticated) {
        debugPrint("⚠️ Not logged in → skipping device token upload");
        return;
      }

      final fcmToken = await FirebaseMessaging.instance.getToken();
      if (fcmToken == null) {
        debugPrint("❌ FCM token null");
        return;
      }

      debugPrint("📤 Uploading Device Token → $fcmToken");

      final res = await http.post(
        Uri.parse("https://doxy-bh96.onrender.com/api/notifications/register"),
        headers: _headers(),
        body: jsonEncode({
          "token": fcmToken,
          "deviceInfo": {"platform": "android"},
        }),
      );

      debugPrint("✅ Backend Response: ${res.body}");
    } catch (e) {
      debugPrint("❌ Device token upload failed: $e");
    } finally {
      _isSendingDeviceToken = false;
    }
  }

  // ============================================================
  // 🟩 SIGNUP
  // ============================================================
  Future<Map<String, dynamic>> signup(
      String name, String email, String password) async {
    try {
      isLoading = true;
      notifyListeners();

      final res = await http.post(
        Uri.parse("$API_BASE_URL/signup"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "name": name,
          "email": email,
          "password": password,
        }),
      );

      final data = jsonDecode(res.body);

      if (res.statusCode == 200 || res.statusCode == 201) {
        await saveToken(data["token"]);
        return {"ok": true};
      }

      return {"ok": false, "message": data["message"] ?? "Signup failed"};
    } catch (e) {
      return {"ok": false, "message": e.toString()};
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  // ============================================================
  // 🟦 LOGIN
  // ============================================================
  Future<Map<String, dynamic>> login(String email, String password) async {
    try {
      isLoading = true;
      notifyListeners();

      final res = await http.post(
        Uri.parse("$API_BASE_URL/login"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "email": email,
          "password": password,
        }),
      );

      final data = jsonDecode(res.body);

      if (res.statusCode == 200) {
        await saveToken(data["token"]);
        return {"ok": true};
      }

      return {"ok": false, "message": data["message"] ?? "Login failed"};
    } catch (e) {
      return {"ok": false, "message": e.toString()};
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  // ============================================================
  // 🟨 GOOGLE LOGIN
  // ============================================================
  Future<void> loginWithGoogle() async {
    try {
      isLoading = true;
      notifyListeners();

      final url = "$API_BASE_URL/google?state=mobile";
      debugPrint("🌍 Google Auth URL → $url");

      final res = await http.get(Uri.parse(url));
      final data = jsonDecode(res.body);

      final authUrl = data["authUrl"];
      if (authUrl == null || authUrl.isEmpty) {
        throw "❌ Google Auth URL missing from backend";
      }

      debugPrint("🚀 Opening Google Login → $authUrl");

      await launchUrl(
        Uri.parse(authUrl),
        mode: LaunchMode.externalApplication,
      );
    } catch (e) {
      debugPrint("❌ Google Login Error: $e");
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  // ============================================================
  // 🟩 GET PROFILE
  // ============================================================
  Future<Map<String, dynamic>> getMe() async {
    try {
      final res = await http.get(
        Uri.parse("$API_BASE_URL/me"),
        headers: _headers(),
      );

      final data = jsonDecode(res.body);

      if (res.statusCode == 200) {
        return {"ok": true, "data": data};
      }

      return {"ok": false, "message": data["message"] ?? "Error"};
    } catch (e) {
      return {"ok": false, "message": e.toString()};
    }
  }

  // ============================================================
  // 🟥 LOGOUT
  // ============================================================
  Future<void> logout() async {
    try {
      await http.post(Uri.parse("$API_BASE_URL/logout"), headers: _headers());
    } catch (_) {}

    await removeToken();
  }

  Future<bool> hasToken() async {
    final t = await _storage.read(key: "jwt_token");
    return t != null && t.isNotEmpty;
  }

  // ============================================================
// 🟦 UNIVERSAL TOKEN GETTER (used by calendar_service)
// ============================================================
  Future<String?> getToken() async {
    // 1. If token already in memory → return
    if (token != null && token!.isNotEmpty) {
      return token;
    }

    // 2. Otherwise load from secure storage
    final stored = await _storage.read(key: "jwt_token");

    if (stored != null && stored.isNotEmpty) {
      token = stored; // keep in memory for fast use
      return stored;
    }

    // 3. No token found
    return null;
  }
}
