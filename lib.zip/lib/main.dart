// ------------------------------
//        FINAL FIXED CODE
// ------------------------------

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:audioplayers/audioplayers.dart';

import 'firebase_options.dart';
import 'services/auth_service.dart';
import 'services/enhanced_notification_service.dart';
import 'services/local_tts_service.dart';

import 'screens/splash_screen.dart';
import 'screens/main_wrapper.dart';
import 'screens/home_dashboard.dart';
import 'screens/calendar_screen.dart';
import 'screens/health_screen.dart';
import 'screens/login_page.dart';

/// GLOBAL AUDIO (usable from background isolate)
final AudioPlayer _globalAudioPlayer = AudioPlayer();

/// Local notification plugin
final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

/// ===========================================================================
/// 🔥 BACKGROUND FCM HANDLER (FULLY FIXED)
/// ===========================================================================
@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  final title = message.notification?.title ?? "Reminder";
  final body = message.notification?.body ?? "";
  final audioUrl = message.data["audioUrl"];

  print("🔕 BG Notification: $title");
  print("🎤 BG audioUrl = $audioUrl");

  /// Always show notification
  await EnhancedNotificationService.showInstantNotification(
    title: title,
    body: body,
  );

  /// Background can ONLY play MP3 URLs
  if (audioUrl != null && audioUrl.toString().isNotEmpty) {
    try {
      await _globalAudioPlayer.stop();
      await _globalAudioPlayer.play(UrlSource(audioUrl));
      print("🎧 Background audio playing OK");
    } catch (e) {
      print("❌ Background audio failed: $e");
    }
  } else {
    print("⚠️ BG TTS skipped (Android restricts background speech).");
  }
}

/// ===========================================================================
/// 🔥 MAIN
/// ===========================================================================
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  print("🔥 Firebase initialized");

  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

  /// Foreground notifications
  await FirebaseMessaging.instance.setForegroundNotificationPresentationOptions(
    alert: true,
    badge: true,
    sound: true,
  );

  /// Local notification init
  const init = AndroidInitializationSettings('@mipmap/ic_launcher');
  const settings = InitializationSettings(android: init);
  await flutterLocalNotificationsPlugin.initialize(settings);

  /// Create "doxys_reminders" channel
  const AndroidNotificationChannel reminderChannel = AndroidNotificationChannel(
    'doxys_reminders',
    'Doxy Reminders',
    description: 'Reminder notifications',
    importance: Importance.max,
  );

  await flutterLocalNotificationsPlugin
      .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>()
      ?.createNotificationChannel(reminderChannel);

  /// Permissions
  await _askPermissions();

  /// Start WS + local queue engine
  await EnhancedNotificationService.init();

  runApp(const DoxyApp());
}

/// ===========================================================================
/// 🔥 ASK PERMISSIONS
/// ===========================================================================
Future<void> _askPermissions() async {
  await Permission.notification.request();
  await Permission.microphone.request();
  await Permission.storage.request();

  if (await Permission.scheduleExactAlarm.isDenied) {
    await Permission.scheduleExactAlarm.request();
  }
  print("📌 Permissions granted");
}

/// ===========================================================================
/// APP ROOT
/// ===========================================================================
class DoxyApp extends StatelessWidget {
  const DoxyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<AuthService>(create: (_) => AuthService()),
      ],
      child: Consumer<AuthService>(
        builder: (context, auth, _) {
          if (auth.isAuthenticated) {
            FirebaseMessaging.instance.getToken().then((token) {
              print("📡 Token on login: $token");
              auth.sendDeviceTokenToServer();
            });
          }

          return MaterialApp(
            navigatorKey: GlobalKeys.navigatorKey,
            debugShowCheckedModeBanner: false,
            theme: ThemeData.dark(),
            home: AppLifecycleHandler(
              child: SplashScreen(
                userHasToken: auth.isAuthenticated,
              ),
            ),
            onGenerateRoute: _onRoute,
          );
        },
      ),
    );
  }

  Route? _onRoute(RouteSettings settings) {
    if (settings.arguments is Map<String, dynamic>) {
      final args = settings.arguments as Map<String, dynamic>;

      switch (args["type"]) {
        case "medication":
          return MaterialPageRoute(builder: (_) => const HealthScreen());
        case "event":
        case "appointment":
          return MaterialPageRoute(
              builder: (_) => const EnhancedCalendarScreen());
        case "task":
          return MaterialPageRoute(builder: (_) => const HomeDashboard());
      }
    }

    switch (settings.name) {
      case "/home":
        return MaterialPageRoute(builder: (_) => const MainWrapper());
      case "/login":
        return MaterialPageRoute(builder: (_) => const LoginPage());
      default:
        return MaterialPageRoute(builder: (_) => const SplashScreen());
    }
  }
}

/// ===========================================================================
/// GLOBAL NAV KEY
/// ===========================================================================
class GlobalKeys {
  static final navigatorKey = GlobalKey<NavigatorState>();
}

/// ===========================================================================
/// 🔥 FOREGROUND HANDLER (FULL FIX)
/// ===========================================================================
class AppLifecycleHandler extends StatefulWidget {
  final Widget child;
  const AppLifecycleHandler({Key? key, required this.child}) : super(key: key);

  @override
  State<AppLifecycleHandler> createState() => _AppLifecycleHandlerState();
}

class _AppLifecycleHandlerState extends State<AppLifecycleHandler>
    with WidgetsBindingObserver {
  final AudioPlayer _player = AudioPlayer();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    FirebaseMessaging.onMessage.listen((message) async {
      final title = message.notification?.title ?? "Reminder";
      final body = message.notification?.body ?? "";
      final audioUrl = message.data["audioUrl"];

      print("📩 FG Notification: $title");
      print("🎤 FG audioUrl = $audioUrl");

      /// Show visual notification
      await flutterLocalNotificationsPlugin.show(
        DateTime.now().millisecondsSinceEpoch ~/ 1000,
        title,
        body,
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'doxys_reminders',
            'Doxy Reminders',
            importance: Importance.max,
          ),
        ),
      );

      /// AUDIO LOGIC
      try {
        // If backend audio available → play
        if (audioUrl != null && audioUrl.toString().isNotEmpty) {
          await _player.stop();
          await _player.play(UrlSource(audioUrl));
          print("🎧 FG backend audio playing");
        } else {
          // Otherwise fallback TTS
          await LocalTTS.speak("$title. $body");
          print("🔊 FG TTS fallback played");
        }
      } catch (e) {
        print("❌ FG audio error → fallback TTS");
        await LocalTTS.speak("$title. $body");
      }
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _player.dispose();
    EnhancedNotificationService.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => widget.child;
}
